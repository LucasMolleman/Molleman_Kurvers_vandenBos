<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>earnings</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157547;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage157549.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157548.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        
        <script>/*bonus payment: fetch the relevant round and decision (part A or B)*/
relevantDec = getValue('decisions', 'playerNr='+playerNr+' and period=1', 'relevant_dec');
relevantRound = Math.ceil(relevantDec/2); // which round is selected for payment?
relevantEst=relevantDec%2; // which estimate in that round is selected?

// get relevant decision and correct answer
animal_names = ['ants', 'bees','flamingos',  'cranes', 'crickets', 'gnus','herrings', 'ladybugs'];
corrAnsw = [93,78,59,74,69];
thisCorr = corrAnsw[relevantRound-1];

relevantAnimal = animal_names[relevantRound-1];
relevantVarName = 'firstEstimate';
var AorB = 'A';
if (relevantDec%2==0) {
    relevantVarName = 'secondEstimate';
    AorB = 'B'
}

// calculate deviation and earnings
est = getValue('decisions', 'playerNr='+playerNr+' and period='+relevantRound, relevantVarName);
deviation = Math.abs(est - thisCorr);
subtraction = Math.min(100, 5 * deviation);
//points = Math.max(100 - Math.pow(deviation,2), 0);
points = Math.max(100 - deviation * 5, 0);

/* define texts shown on-screen */
subtractionT = 'As a consequence, we subtract ' + deviation + ' x 5 = ' + subtraction + ' Points.'
if (deviation > 20) {
    subtractionT = 'As a consequence, we would have subtracted  ' + deviation + ' x 5 Points. <br>'
    subtractionT += 'However, as stated in the instructions, your number of Points cannot become negative, so we subtract 100 Points.';
    
}
/*store bonus in database*/
record('pointsEarned', points);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        <div class="col-sm-12" id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Your earnings</h3><p>Your earnings are calculated as follows.<br></p><p></p><p>The computer randomly selected round <b><script>document.write(relevantRound)</script></b>.<br>Then, the computer randomly selected <b>part <script>document.write(AorB)</script></b>.<br>In that case, you estimated how many <b><script>document.write(relevantAnimal)</script></b> there were in the image.</p><p>Your estimate in that case was<b> <script>document.write(est)</script></b>.<br>The actual number of <script>document.write(relevantAnimal)</script> in the image was <b><script>document.write(thisCorr)</script></b>.</p><p>This means that your estimate was&nbsp;<b><script>document.write(deviation)</script></b> off the actual number.<br><script>document.write(subtractionT)</script></p><p>This means that your earnings from Task <script>document.write(partT)</script> are 100 - <script>document.write(subtraction)</script> = <b><script>document.write(points)</script> Points</b>.<br></p><p></p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 18-->
        
        <div class="col-sm-12" id="wrap3" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button3">
        <div id="buttonclick3" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload3').show();
        if (additionalCheck3()) {
            hideError3();
            if (checkEntries()) toNextPage3();
            else  { $(this).show(); 
            $('#buttonload3').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload3').hide();
         }
        ">Continue</div><div id="buttonload3" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field3_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field3_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field3_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field3_attempts').show();
        
        }
        function showError3(text) {
            var errorfield= $('#field3_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError3() {
            $('#field3_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    fn = window[name]; /* this is a generic function calling the checker for the variable "name"  */
                    fnExists = typeof fn === "function";
                    if (fnExists) {
                        fn();
                        ++numValuesExpected;
                    }
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck3() {

           return true;
        }

       



        function checkFail() {} function toNextPage3() {
            if (loopEnd==157548) { showNext('wait157548.php?session_index=<?php echo $_SESSION[sessionID];?>',157549,157548);}
            else {showNext('stage157549.php?session_index=<?php echo $_SESSION[sessionID];?>',157549,157548);}

            };</script></div><script>if((true)) { $('#wrap3').show(); $('#buttonclick3').addClass('buttonclick');} </script><!-- END Element 3 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide(); }, 100);</script></form></div></body></html>