DROP TABLE IF EXISTS  `e1433g13999_globals`;SELECT 1;CREATE TABLE `e1433g13999_globals` (
                  `name` varchar(36) NOT NULL,
                  `value` TEXT NOT NULL
                );SELECT 1;INSERT INTO `e1433g13999_globals` (`name`, `value`) VALUES ('compiled', '1565364598'),('active', '1'),('testMode', '0'),('totalPlayers', '200'),('groupSize', '1'),('numberPeriods', '1'),('loopStart', ''),('loopEnd', ''),('participationFee', '1.50'),('exchangeRate', '0.01'),('popup', ''),('dropoutHandling', '3'),('sortableMatching', '1'),('message0', 'This HIT is currently offline. You cannot participate at this time.'),('message1', 'According to our records, your device has already been connected to the server during this session. &lt;br&gt;                Participants are only allowed to enter a session once. Thank you for your understanding.'),('message2', 'We have sufficient participants for this HIT. &lt;br&gt;Unfortunately, you cannot participate at this time. &lt;br&gt;&lt;br&gt;                Thank you for your understanding.'),('message3', 'You are currently not logged in. You cannot participate in the HIT.'),('message4', 'Unfortunately, this HIT was terminated for a technical reason! &lt;br&gt;&lt;br&gt;&lt;br&gt;                You cannot continue. &lt;br&gt;&lt;br&gt;&lt;br&gt;                You will receive your guaranteed participation fee of $ $participationFee$.                To collect your earnings, please fill out this random code on MTurk.                &lt;br&gt;&lt;br&gt;&lt;b&gt;$randomid$&lt;/b&gt;.                &lt;br&gt;                Once you have filled out this code, you can close this window.                Thank you for your participation.'),('message5', 'You did not make a decision before the time was up. &lt;br&gt;&lt;br&gt; You have been removed from the HIT. &lt;br&gt;&lt;br&gt;                        You can close down this window.'),('message6', 'Unfortunately, one of the players in your group dropped out of the HIT! &lt;br&gt;&lt;br&gt;&lt;br&gt;                 You cannot continue. &lt;br&gt;&lt;br&gt;&lt;br&gt;You will receive your guaranteed participation fee of                  $ $participationFee$.                 To collect your earnings, please fill out this random code on MTurk.                 &lt;br&gt;&lt;br&gt;&lt;b&gt;$randomid$&lt;/b&gt;.                 &lt;br&gt;                 Once you have filled out this code, you can close this window.                 Thank you for your participation.'),('message7', 'As indicated in our HIT text on MTurk, our HIT does &lt;b&gt;not&lt;/b&gt; support Microsoft Internet Explorer. &lt;br&gt;                         Please return this HIT.                         &lt;br&gt;                         We apologise for any inconvenience caused.'),('message8', 'You did not answer the quiz correctly and were excluded from further participation                                               '),('img_size', '50'),('border', '50'),('overlap_ratio', '0.5');SELECT 1;ALTER TABLE e1433g13999_globals ADD PRIMARY KEY(`name`);SELECT 1;DROP TABLE IF EXISTS `e1433g13999_decisions`;SELECT 1;CREATE TABLE IF NOT EXISTS `e1433g13999_decisions` (
                  `playerNr` int(11),
                  `groupNr` int(11),
                  `subjectNr` int(11),
                  `period` int(11)
                  ,`relevant_dec`   TEXT,`q1`   TEXT,`q2`   TEXT,`q3`   TEXT,`nAnimals`   TEXT,`firstEstimate`   TEXT,`social_info`   TEXT,`secondEstimate`   TEXT,`adjustment`   TEXT,`pointsEarned`   TEXT,`time_157537` float ,`time_157538` float ,`time_157539` float ,`time_157540` float ,`time_157541` float ,`time_157542` float ,`time_157543` float ,`time_157544` float ,`time_157545` float ,`time_157546` float ,`time_157547` float ,`time_157548` float ,`time_157549` float );SELECT 1;ALTER TABLE e1433g13999_decisions ADD PRIMARY KEY( `playerNr`, `period`);SELECT 1;DROP TABLE IF EXISTS `e1433g13999_logEvents`;SELECT 1;CREATE TABLE IF NOT EXISTS `e1433g13999_logEvents` (
                  `eventNr` int(11) NOT NULL AUTO_INCREMENT,
                  `groupNr` int(11) NOT NULL,
                  `playerNr` int(11) NOT NULL,
                  `timeEvent` varchar(256) NOT NULL,
                  `event` varchar(256) NOT NULL,
                  PRIMARY KEY(eventNr)
                );SELECT 1;DROP TABLE IF EXISTS `e1433g13999_core`;SELECT 1;CREATE TABLE IF NOT EXISTS `e1433g13999_core` (
                      `playerNr` int(11) NOT NULL AUTO_INCREMENT,                   
                      `groupNr` int(11) NOT NULL,
                      `subjectNr` int(11) NOT NULL,
                      `groupNrStart` int(11) NOT NULL,
                      `currentGroupSize` int(11) NOT NULL,
                      `period` int(11) NOT NULL,
                      `onPage` varchar(30) NOT NULL,
                      `connected` boolean,
                      `tStart` int(11) NOT NULL,
                      `lastActionTime` int(11) NOT NULL,
                      `ipaddress` varchar(99) NOT NULL,
                      `ipaddress_part` varchar(15) NOT NULL,
                      `location` varchar(40) NULL,
                      `waitMore` int(11) NOT NULL,
                      `lobbyReady` boolean,
                      `enterLobby` INT(11),
                      `role` INT(11),`wait_157537ready` boolean,`wait_157538ready` boolean,`wait_157539ready` boolean,`wait_157540ready` boolean,`wait_157541ready` boolean,`wait_157542ready` boolean,`wait_157543ready` boolean,`wait_157544ready` boolean,`wait_157545ready` boolean,`wait_157546ready` boolean,`wait_157547ready` boolean,`wait_157548ready` boolean,`wait_157549ready` boolean,`wait_lastInPeriod` boolean,
                      `periodReady` boolean,
                      `leftExperiment` boolean,
                      `experimentTerminated` boolean,
                      `groupAborted` boolean,
                      PRIMARY KEY (playerNr)
                    );SELECT 1;DROP TABLE IF EXISTS `e1433g13999_session`;SELECT 1;CREATE TABLE IF NOT EXISTS `e1433g13999_session` (
                  `playerNr` int(11) NOT NULL,
                  `randomid` VARCHAR(256) NOT NULL,
                  `randomidNotPlayed` VARCHAR(256)   NOT NULL,
                  `relevantRandomid` varchar(256) NOT NULL,
                  `externalID` varchar(256) NULL,
                  `participationAmount` decimal(11,2) NOT NULL,
                  `bonusAmount` decimal(11,2) NOT NULL,
                  `totalEarnings` decimal(11,2) NOT NULL,`q1_fail`   int(11) DEFAULT 0,`q2_fail`   int(11) DEFAULT 0,`q3_fail`   int(11) DEFAULT 0,`quizFail` int(11) DEFAULT 0,
                    PRIMARY KEY (playerNr)
                  );SELECT 1;TRUNCATE `e1433g13999_session`;SELECT 1;