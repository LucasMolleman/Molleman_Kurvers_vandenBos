<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>instructions 2</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157539;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage157541.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157540.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 1-->
        
        <div class="col-sm-12" id="wrap1" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Instructions 2/3</h3><p>Once the image has disappeared, you have to enter your estimate of how many animals were displayed.&nbsp;<br>You have to enter your estimate within <b>15 seconds</b>.<br>This is your estimate for <b>part A</b> of a round.<br></p><p>Once you have entered your estimate, <b>part B</b> of the round begins.<br>You can observe the <i>part A estimate of another MTurker</i>.&nbsp;</p><p>Over 100 MTurkers participated in a previous session in which they completed this task.<br>In each round, you can observe the part A estimate of one of these previous MTurkers.</p><p><span style="background-color: initial;">The previous MTurkers saw the same image as you. They also saw it for 6 seconds.&nbsp;<br></span><span style="background-color: initial;">After the image disappeared, they also had to estimate how many animals were displayed.<br></span><span style="background-color: initial;">They could also earn a higher bonus if their estimate was more accurate.&nbsp;</span><br></p><p>You then have to <b>enter a second estimate</b>.<br>You can enter the same estimate as in part A, or adjust it as you wish.<br>You have to enter your second estimate within <b>45 seconds</b>.<br>This is your estimate for <b>part B</b> of a round.</p><p><i>Note: if you do not enter your estimate within the time limit, you will be removed from the HIT and we will not be able to pay you.</i><br>Once you have entered your part B estimate, the round is over and a new round begins.<br></p><p></p></div>
        </div><script>if((true)) { $('#wrap1').show(); } </script><!-- END Element 1 Type: 1-->
        
        <!-- START Element 2 Type: 18-->
        
        <div class="col-sm-12" id="wrap2" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button2">
        <div id="buttonclick2" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload2').show();
        if (additionalCheck2()) {
            hideError2();
            if (checkEntries()) toNextPage2();
            else  { $(this).show(); 
            $('#buttonload2').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload2').hide();
         }
        ">Continue</div><div id="buttonload2" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field2_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field2_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field2_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field2_attempts').show();
        
        }
        function showError2(text) {
            var errorfield= $('#field2_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError2() {
            $('#field2_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    fn = window[name]; /* this is a generic function calling the checker for the variable "name"  */
                    fnExists = typeof fn === "function";
                    if (fnExists) {
                        fn();
                        ++numValuesExpected;
                    }
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck2() {

           return true;
        }

       



        function checkFail() {} function toNextPage2() {
            if (loopEnd==157540) { showNext('wait157540.php?session_index=<?php echo $_SESSION[sessionID];?>',157541,157540);}
            else {showNext('stage157541.php?session_index=<?php echo $_SESSION[sessionID];?>',157541,157540);}

            };</script></div><script>if((true)) { $('#wrap2').show(); $('#buttonclick2').addClass('buttonclick');} </script><!-- END Element 2 Type: 18-->
        
        <!-- START Element 3 Type: 18-->
        
        <div class="col-sm-12" id="wrap3" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button3">
        <div id="buttonclick3" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload3').show();
        if (additionalCheck3()) {
            hideError3();
            if (checkEntries()) toNextPage3();
            else  { $(this).show(); 
            $('#buttonload3').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload3').hide();
         }
        ">Go back</div><div id="buttonload3" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field3_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field3_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field3_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field3_attempts').show();
        
        }
        function showError3(text) {
            var errorfield= $('#field3_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError3() {
            $('#field3_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    fn = window[name]; /* this is a generic function calling the checker for the variable "name"  */
                    fnExists = typeof fn === "function";
                    if (fnExists) {
                        fn();
                        ++numValuesExpected;
                    }
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck3() {

           return true;
        }

       



        function checkFail() {} function toNextPage3() {
            if (loopEnd==157540) { showNext('wait157540.php?session_index=<?php echo $_SESSION[sessionID];?>',157539,157540);}
            else {showNext('stage157539.php?session_index=<?php echo $_SESSION[sessionID];?>',157539,157540);}

            };</script></div><script>if((true)) { $('#wrap3').show(); $('#buttonclick3').addClass('buttonclick');} </script><!-- END Element 3 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap1').show();if (!(true)) $('#wrap1').hide();if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide(); }, 100);</script></form></div></body></html>