<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>revise</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157545;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=45;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage157547.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157546.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        
        <script>/*fetch correct answer (true number of animals in the image) */
corrA = [93,78,59,74,69];
corr = corrA[period-1];

/*fetch animal name */
animal_names = ['ants', 'bees', 'flamingos', 'cranes', 'crickets'];
animal_name = animal_names[period-1]; // starts counting at 0

/*fetch participant's first estimate in this period */
firstGuess = getValue('firstEstimate');


/*======== find social information at predefined 'target' distance (defined in 'devs') ===========*/
/* estimates from previous session (without social information) */
peersMat = [
    [20,24,25,30,33,35,35,38,40,42,43,45,45,46,48,50,50,50,50,52,55,55,56,56,57,60,60,60,60,62,64,64,64,65,65,65,65,67,67,69,69,70,70,70,70,70,70,70,70,70,72,72,72,74,75,75,75,75,75,75,75,75,76,78,80,80,80,80,80,80,80,84,85,85,85,85,85,86,89,89,90,90,95,98,100,100,100,120,120,120,120,120,125,126,130,155],
    [28,30,30,30,30,35,37,40,40,41,44,45,47,49,50,50,52,53,55,56,56,56,58,58,59,60,60,60,60,60,60,60,62,62,62,62,63,63,65,65,65,65,65,68,68,68,70,70,70,70,70,70,70,72,72,74,75,75,75,77,77,77,78,80,80,80,80,80,80,80,80,80,84,84,85,85,85,85,88,90,90,90,90,90,91,98,100,100,100,100,103,103,110,110,110,145],
    [18,30,30,30,30,34,35,35,35,38,40,40,40,40,42,44,45,45,45,45,45,45,45,48,48,48,48,48,49,50,50,50,50,50,50,50,50,50,51,51,52,52,52,52,54,54,55,55,55,55,55,55,55,55,56,56,58,59,60,60,60,60,60,60,60,64,64,65,65,65,65,65,65,65,65,65,66,66,68,70,70,75,75,75,75,79,80,80,81,86,86,88,89,95,100,101],    
    [20,21,25,40,40,41,42,45,45,46,47,48,48,50,50,53,55,55,55,55,55,55,55,56,58,58,60,60,60,60,62,64,65,65,65,65,65,67,67,68,69,70,70,70,70,70,70,70,70,70,70,70,70,71,72,73,74,75,75,75,75,75,75,75,76,77,78,80,80,80,80,80,80,80,80,83,88,88,88,90,90,90,92,95,95,100,100,101,102,110,110,110,120,121,140,150],
    [23,25,28,30,32,33,33,34,35,38,40,40,40,40,40,41,42,42,45,45,47,48,49,50,50,50,50,53,53,54,55,55,55,55,55,55,55,55,56,57,57,58,58,59,60,60,60,60,60,60,60,60,60,62,62,62,62,62,65,65,65,65,65,65,65,66,66,66,66,68,68,69,70,70,70,70,72,72,73,75,75,75,76,77,80,80,80,84,85,85,90,92,102,110,125,140]
    ];

/* store the relevant vector for this round in a variable called peers */    
peers = peersMat[period-1];

// which deviation applies in this round?
devs = [0.25, 0.15, 0.2, 0.15, 0.25];
thisDev = devs[period-1];

/* social information always points in the direction of the true value */
// if lower than corr
target = firstGuess * (1 + thisDev);
// if higher than corr
if (firstGuess > corr){
    target = firstGuess * (1 - thisDev);
}
// if guess == corr, random higher or lower
if (firstGuess == corr){
    if (Math.random()<0.5) target = firstGuess * (1 - thisDev);
}

/*function to find an estimate from the previous session closest to the target value */
closestNumber = [];
minDev = 10000;
for (var i=0; i<peers.length; i++) {
    var dev = Math.abs(peers[i] - target)
    if (dev < minDev){
        minDev = dev;
        closestNumber=[]
        closestNumber.push(peers[i]);
    }
    if (dev == minDev){
        closestNumber.push(peers[i]);        
    }
}

closestNumber = shuffle(closestNumber);
obsSoc = closestNumber[0];

/*save the displayed social information in the database */
record('social_info', obsSoc);

/*in the first round, give more time*/
if (period==1) TimeOut=60;</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        <div class="col-sm-12" id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Round <script>document.write(period)</script>: part B estimate</h3>Your part A estimate of <b><script>document.write(firstGuess)</script></b> has been recorded.<p><span style="background-color: initial;">Now, we show you the part A estimate of an MTurker who completed this task before.<br></span><span style="background-color: initial;">This previous MTurker saw the same image as you just did. They also saw it for 6 seconds.<br></span></p><p><span style="background-color: initial;">Their estimate was</span><span style="background-color: initial;">:&nbsp;</span><b style="background-color: initial;"><script>document.write(obsSoc)</script></b></p><p><span style="background-color: initial;">You can now enter your part B estimate below.</span></p><p></p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 20-->
        
        <div class="col-sm-12" id="wrap3" style="display: none;"><div class="bntbox2"  style="vertical-align: middle;"><div class="form-group btnbox2 btnbox2"><label for="field3"><b>How many <script>document.write(animal_name)</script> were shown in the image?</b></label><input name="3" id="field3"

                            type="text"

                            size="10"

                            maxlength="10"

                            max="1000"

                            step="0"

                            value=""
                            
                            onchange="secondEstimate=parseFloat(this.value);"
                            class="form-control input-lg" style="text-align: center;"><div id="field3_minmax" class=" messagefield3 alert alert-danger" style="display: none;">Please enter a number between 0 and 1000.</div><div id="field3_noNumber" class="messagefield3 alert alert-danger" style="display: none;">Please enter a number. </div><div id="field3_tooManyDigits" class="messagefield3 alert alert-danger" style="display: none;">You entered too many digits.</div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div><script>var secondEstimate=null;function checkValue_field3() {
           var label="secondEstimate";var min=0;var max=1000;var digits=0;var correct=null;var required=1;var inline=0;var label1=null;var label2=null;
            if(!(true)) { checker=checker+1; } else {
            
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_secondEstimate !== 'undefined') { value=bot_secondEstimate; }
                    else { value=Math.floor(Math.random()*max)+min; }
                    value=parseFloat(value);
                }
                else {
                value=($('#field3').val()); 
                }
                
                $('.messagefield3').hide();
                
                
                
                var allcorrect=checker+1;
                
                /* check if any entry has been made */
                if ((isNaN(value) || value === "") && required==1) {
                    $('#field3_noNumber').show();
                    
                }
                else if (isNaN(value)) {
                    $('#field3_noNumber').show();
                    
                }
                else {
                  


                    var digs = 0;
                    if (value % 1 !==0 && typeof value != undefined) {
                        var testvalue=value.toString();
                        digs = testvalue.split(".")[1].length;
                    }
                    if (digs>digits){ $('#field3_tooManyDigits').show(); }
                    else {
                        if (value>max || value < min) {
                            $('#field3_minmax').show();
                           
                        }
                        else { 

                        if (value!=correct && correct != null && required!=0) {
                           
                           
                            $('#field3_notcorrect').show();
                        } else {


                            record("secondEstimate", value);

                           checker = checker+1;
                       }
                       }
                   }
               }
               if (allcorrect!=checker) {
                  wronganswers['secondEstimate']=1;
                  totalwronganswers['secondEstimate'] = isNaN(totalwronganswers['secondEstimate']) ? 1 : totalwronganswers['secondEstimate']+1; 
                } else wronganswers['secondEstimate']=0;
            }

}

        </script></div></div></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 20-->
        
        <!-- START Element 4 Type: 18-->
        
        <div class="col-sm-12" id="wrap4" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button4">
        <div id="buttonclick4" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload4').show();
        if (additionalCheck4()) {
            hideError4();
            if (checkEntries()) toNextPage4();
            else  { $(this).show(); 
            $('#buttonload4').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload4').hide();
         }
        ">Continue</div><div id="buttonload4" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field4_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field4_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field4_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field4_attempts').show();
        
        }
        function showError4(text) {
            var errorfield= $('#field4_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError4() {
            $('#field4_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    fn = window[name]; /* this is a generic function calling the checker for the variable "name"  */
                    fnExists = typeof fn === "function";
                    if (fnExists) {
                        fn();
                        ++numValuesExpected;
                    }
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck4() {

           return true;
        }

       



        function checkFail() {} function toNextPage4() {
            if (loopEnd==157546) { showNext('wait157546.php?session_index=<?php echo $_SESSION[sessionID];?>',157547,157546);}
            else {showNext('stage157547.php?session_index=<?php echo $_SESSION[sessionID];?>',157547,157546);}

            };</script></div><script>if((true)) { $('#wrap4').show(); $('#buttonclick4').addClass('buttonclick');} </script><!-- END Element 4 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide(); }, 100);</script><script>countdownTimer(TimeOut, '_timeoutDecision.php?session_index=<?php echo $_SESSION[sessionID];?>',true);</script></form></div></body></html>