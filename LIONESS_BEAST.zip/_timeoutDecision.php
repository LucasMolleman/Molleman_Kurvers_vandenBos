<?php
include('_projectID.php');
include(PATH."basis/LIONESS.php");

?>
<html>
	<head>
		<link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
		<link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />


		<title>Experiment terminated</title>

		<script>
			/* stop signalling presence */
			clearTimeout(connect);
			w.terminate();
			/* log that this player is excluded */
			var logMessage = 'Player ' + playerNr + ' was excluded due to timeout.';
			var groupNr1 = 999;
			if (groupNr) groupNr1=groupNr;
			var time1 = getServerTime();

			insertRecord('logEvents', "groupNr, playerNr, timeEvent", [groupNr1 , playerNr, time1]);
			/*insertRecord('logEvents', 'groupNr, playerNr', [groupNr1 , playerNr]);*/
			setValue('logEvents', 'playerNr=' + playerNr + ' and timeEvent='+time1, 'event', logMessage);

			setValue('core', 'playerNr='+playerNr, 'leftExperiment', 1);

	/*		location.replace('ext/experimentEndedTimeout.html');
			setValue('decisions', 'playerNr='+playerNr+' and period='+period, 'contribution', Math.floor(Math.random() * 20));
			setValue('decisions', 'playerNr='+playerNr+' and period='+period, 'decisionTime', 999);
			location.replace('wait_1.php'); */
			
		</script>
	<head>

<body>
	<br><br><br><br><br><br><br>
<div class="alert alert-warning" style="text-align: center">
		You did not make a decision before the time was up. <br><br> You have been removed from the experiment. <br><br>
		You can close down this window.

</body>
</html>