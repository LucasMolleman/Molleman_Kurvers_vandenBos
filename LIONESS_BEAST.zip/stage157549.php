<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>finished</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157548;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157549.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        
        <script>//fetch earnings to show on screen alongside the random code for MTurk
points = getValue('pointsEarned');
dollars = points * parseFloat(exchangeRate);
dollars = Math.min(dollars,2); // do not let payment go above 2 (an unelegant safety pin)
dollarsT = '$'+dollars.toFixed(2);

/*save bonus in the sessions table*/
setBonus(dollars);

feeT = '$'+parseFloat(participationFee).toFixed(2);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        <div class="col-sm-12" id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Earnings</h3>This is the end of this HIT. You earned<span style="background-color: rgba(223, 240, 216, 0);">&nbsp;</span><b style="background-color: rgba(223, 240, 216, 0);"><script>document.write(points)</script> Points</b><span style="background-color: rgba(223, 240, 216, 0);">.</span><p>These Points are worth <b><script>document.write(dollarsT)</script></b>.&nbsp;<span style="background-color: initial;">This is your bonus for this HIT.<br></span><span style="background-color: initial;">Note that any bonus you earn will be paid on top of your guaranteed participation fee of </span><b style="background-color: initial;"><script>document.write(feeT)</script></b><span style="background-color: initial;">.&nbsp;</span><span style="background-color: initial;"><br></span></p><p><span style="background-color: initial;">To collect your payment for the HIT you just completed, please fill out the below code on MTurk.</span><br></p><p><b><script>document.write(randomid)</script></b></p><p>Once you have done that, you can close this window.&nbsp;<br>Thank you for your participation!</p><p></p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide(); }, 100);</script></form></div></body></html>