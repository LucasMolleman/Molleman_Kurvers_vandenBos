<?php

	// first define the host, the database name, the username (admin), and the password
	define ("HOST","localhost");
	define ("ADMIN","");
	define ("DBNAME","");
	define ("PASSW","");
