<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>watch pic</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157543;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=6;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage157545.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157544.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        
        <script>/*get number of animals in current round */
corrA = [93,78,59,74,69];
numberAnimals = corrA[period-1];

//store all the names of the animals
animal_names =['ant', 'bee', 'flamingo', 'crane', 'cricket'];
animal_name = animal_names[period-1];

/* ==== define screen for printing animals in random positions on the screen (yet constant across participants due to 'seed') ===== */

//get fixed picture parameters 
var animal_size = getParameter('img_size'); //in px
var overlap_ratio = getParameter('overlap_ratio'); 
var border = getParameter('border');

//get screen size and create final size of the picture
var img_width = screen.width/2; // in px
var img_heigth = screen.height/2; // in px
var total_width = img_width + border;
var total_height = img_heigth + border;

//calculate how many positions in the grid  can be obtained given pic size
n_positions = img_width/(animal_size * (overlap_ratio)); 
n_positions_y = img_heigth/(animal_size * (overlap_ratio)); 

// function to generate random numbers according to seed
// unique seeds are set by the period number
seed = period;
function random() {
    var x = Math.sin(seed++) * img_width; // this assumes a 100x100 grid
    return x - Math.floor(x);
}
// fuction to kick out double entries in an array (to have only unique entries)
function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}
 
rnds=[];
for (j=0; j<200; j++) rnds.push(Math.round(random() * img_width));  // draw 200 random numbers
rnds = rnds.filter( onlyUnique ); // remove non-unique values
//document.write(rnds + '<br>') // write to screen for checking
rnds = rnds.slice(0,numberAnimals);
rnds = rnds.sort();

//generate picture
pic = '<div style="text-align:center; margin-left:auto; margin-right:auto">';
pic +='<svg width="'+total_width+'" height="'+total_height+'" style=" background-color: rgb(204,204,255);">';
    //loop through numberAnimals and add pics
for (i = 0; i<numberAnimals; ++i){
    rndx = rnds[i];
    x = rndx%(n_positions)*(img_width/n_positions);
    y = Math.floor(rndx/n_positions)*(n_positions_y);
   pic +='<image xlink:href="http://www.surveycamel.com/hively/animalPictures/'+animal_name+'_small.png" x="'+x+ '" y="'+y+'" height="'+animal_size+'" width="'+animal_size+'"/>';
  }
  
pic+= '</svg> </div>';

/* print the picture to the screen*/
document.write(pic)</script><!-- END Element 1 Type: 19-->
        
        </div><script>setInterval(function(){  }, 100);</script><script>countdownTimer(TimeOut, 'stage157545.php?session_index=<?php echo $_SESSION[sessionID];?>',true);</script></form></div></body></html>