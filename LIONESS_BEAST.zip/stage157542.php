<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css?v1" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>quiz</title>

        <script> var v={}; var wronganswers={}; var totalwronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 157541;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage(proceedifpossible) {
         if (proceedifpossible === undefined) proceedifpossible = false;
         if (proceedifpossible) location.replace('stage157543.php?session_index=<?php echo $_SESSION[sessionID];?>');
         else location.replace('wait157542.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head><body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        
        <script></script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        <div class="col-sm-12" id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Check for understanding</h3><p>To check your understanding of the task, please indicate for each of these statements whether they are correct or incorrect.</div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 23-->
        
        <div class="col-sm-12" id="wrap3" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field3"><script>var q1=null;</script><div style="text-align: center"><label for="field3"><b>In each round of this task you will view an image. You have to estimate how many animals were displayed in it.</b></label></div><div
            id="button31"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
                            $('#button31').addClass('btn-primary');
                             q1=1;
                            $('#field3').val(1);">correct</div><div
            id="button32"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
                            $('#button32').addClass('btn-primary');
                             q1=2;
                            $('#field3').val(2);">incorrect</div><script>var q1_options = [1,2];
        </script><div id="field3_noEntry" class="messagefield3 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>function checkValue_field3() {
           var label="q1";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var multiple=0;var options=null;var clicksave=0;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_q1 !== 'undefined') { value=bot_q1; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field3').val()); 
                }
                                
                $('.messagefield3').hide();
                allcorrect=checker+1;
                if ((value === null || value == "") && required==1) {
                    $('#field3_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field3_notcorrect').show();
                        }
                
                else {
                        

                       record("q1", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['q1']=1;
                       totalwronganswers['q1'] = isNaN(totalwronganswers['q1']) ? 1 : totalwronganswers['q1']+1; 
             
               } else wronganswers['q1']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 23-->
        
        <!-- START Element 4 Type: 23-->
        
        <div class="col-sm-12" id="wrap4" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field4"><script>var q2=null;</script><div style="text-align: center"><label for="field4"><br><b>Once you have entered your estimate, you can observe the estimate of another MTurker who completed this task before. You can then make a second estimate.</b></label></div><div
            id="button41"

            class="choicebuttons4 btn btn-default" onclick="$('.choicebuttons4').removeClass('btn-primary');
                            $('#button41').addClass('btn-primary');
                             q2=1;
                            $('#field4').val(1);">correct</div><div
            id="button42"

            class="choicebuttons4 btn btn-default" onclick="$('.choicebuttons4').removeClass('btn-primary');
                            $('#button42').addClass('btn-primary');
                             q2=2;
                            $('#field4').val(2);">incorrect</div><script>var q2_options = [1,2];
        </script><div id="field4_noEntry" class="messagefield4 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field4_notcorrect" class="messagefield4 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>function checkValue_field4() {
           var label="q2";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var multiple=0;var options=null;var clicksave=0;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_q2 !== 'undefined') { value=bot_q2; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field4').val()); 
                }
                                
                $('.messagefield4').hide();
                allcorrect=checker+1;
                if ((value === null || value == "") && required==1) {
                    $('#field4_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field4_notcorrect').show();
                        }
                
                else {
                        

                       record("q2", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['q2']=1;
                       totalwronganswers['q2'] = isNaN(totalwronganswers['q2']) ? 1 : totalwronganswers['q2']+1; 
             
               } else wronganswers['q2']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 23-->
        
        <!-- START Element 5 Type: 23-->
        
        <div class="col-sm-12" id="wrap5" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field5"><script>var q3=null;</script><div style="text-align: center"><label for="field5"><br><b>The more accurate your estimates, the more Points you can earn.</b></label></div><div
            id="button51"

            class="choicebuttons5 btn btn-default" onclick="$('.choicebuttons5').removeClass('btn-primary');
                            $('#button51').addClass('btn-primary');
                             q3=1;
                            $('#field5').val(1);">correct</div><div
            id="button52"

            class="choicebuttons5 btn btn-default" onclick="$('.choicebuttons5').removeClass('btn-primary');
                            $('#button52').addClass('btn-primary');
                             q3=2;
                            $('#field5').val(2);">incorrect</div><script>var q3_options = [1,2];
        </script><div id="field5_noEntry" class="messagefield5 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field5_notcorrect" class="messagefield5 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>function checkValue_field5() {
           var label="q3";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var multiple=0;var options=null;var clicksave=0;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_q3 !== 'undefined') { value=bot_q3; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field5').val()); 
                }
                                
                $('.messagefield5').hide();
                allcorrect=checker+1;
                if ((value === null || value == "") && required==1) {
                    $('#field5_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field5_notcorrect').show();
                        }
                
                else {
                        

                       record("q3", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['q3']=1;
                       totalwronganswers['q3'] = isNaN(totalwronganswers['q3']) ? 1 : totalwronganswers['q3']+1; 
             
               } else wronganswers['q3']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap5').show(); } </script><!-- END Element 5 Type: 23-->
        
        <!-- START Element 6 Type: 18-->
        
        <div class="col-sm-12" id="wrap6" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button6">
        <div id="buttonclick6" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload6').show();
        if (additionalCheck6()) {
            hideError6();
            if (checkEntries()) toNextPage6();
            else  { $(this).show(); 
            $('#buttonload6').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload6').hide();
         }
        ">Continue</div><div id="buttonload6" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field6_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field6_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field6_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field6_attempts').show();
        
        }
        function showError6(text) {
            var errorfield= $('#field6_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError6() {
            $('#field6_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    fn = window[name]; /* this is a generic function calling the checker for the variable "name"  */
                    fnExists = typeof fn === "function";
                    if (fnExists) {
                        fn();
                        ++numValuesExpected;
                    }
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck6() {

           return true;
        }

       



        function checkFail() {var numFails=quizFail(playerNr,0,wronganswers);
            console.log(numFails);
            if (numFails>=maxFalse && maxFalse!=null) location.replace(path+'HITstop.php?m=<?php echo base64_encode(serialize(array('messageNr'=>8,'projectID'=>PROJECTID))); ?>');
            if (maxFalse!=null && numFails<=maxFalse) $('#field6_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            } function toNextPage6() {
            if (loopEnd==157542) { showNext('wait157542.php?session_index=<?php echo $_SESSION[sessionID];?>',157543,157542);}
            else {showNext('stage157543.php?session_index=<?php echo $_SESSION[sessionID];?>',157543,157542);}

            };</script></div><script>if((true)) { $('#wrap6').show(); $('#buttonclick6').addClass('buttonclick');} </script><!-- END Element 6 Type: 18-->
        
        <!-- START Element 7 Type: 25-->
        
        <div class="col-sm-12" id="wrap7" style="display: none;"><div  id="button7">
        <div class="btn btn-default btn-lg btn-block" onclick="toNextPage7();">Back to instructions</div></div><script>



      


         function toNextPage7() {
            showNext('stage157541.php?session_index=<?php echo $_SESSION[sessionID];?>',157541,157542);

            };</script></div><script>if((true)) { $('#wrap7').show(); } </script><!-- END Element 7 Type: 25-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide();if (true) $('#wrap5').show();if (!(true)) $('#wrap5').hide();if (true) $('#wrap6').show();if (!(true)) $('#wrap6').hide();if (true) $('#wrap7').show();if (!(true)) $('#wrap7').hide(); }, 100);</script></form></div></body></html>