<?php define ("PROJECTID","e1433g13999_");
	    define ("PATH","resources/");
	    define ("FIRSTPAGE","stage157537");
	    define ("PROJECTPW","aef8e86dd3cb6c7b359c0b69cae73c3f");
	    