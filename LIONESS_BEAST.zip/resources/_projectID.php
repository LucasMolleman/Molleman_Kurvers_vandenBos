<?php
/**
 * Created by PhpStorm.
 * User: GIAMAT01
 * Date: 25.11.2015
 * Time: 13:58
 */

define ("PROJECTID","");
define ("PATH","");