<?php

require('sessionStart.php');
$playerNr=$_GET['playerNr'];
$_SESSION['testPlayerNr']=$playerNr;
