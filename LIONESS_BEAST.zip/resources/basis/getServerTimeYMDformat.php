<?php
	echo json_encode(strval(date('Y/m/d H:i:s')));

