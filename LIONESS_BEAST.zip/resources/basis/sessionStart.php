<?php
/**
 * Created by PhpStorm.
 * User: GIAMAT01
 * Date: 10.05.2016
 * Time: 11:04
 */


error_reporting(0);
$session_prefix = 'mysid';

$session_index = isset($_REQUEST['session_index']) ? $_REQUEST['session_index'] : 0;

$active_sessions = [];

foreach ($_COOKIE as $name => $sid) {

    $zerlegtes = explode('_', $name);

    if (2 === count($zerlegtes)) {

        list($prefix, $index) = $zerlegtes;

        if ($session_prefix == $prefix)

            $active_sessions[$index] = $sid;

    }

}


if (!empty($_REQUEST['newsession'])) {

    do

    {

        $index = mt_rand();

    }while(isset($active_sessions[$index]));

    $session_index=md5($index);


}



session_name($session_prefix . '_' . $session_index);

session_start();

output_add_rewrite_var('session_index', $session_index);

$_SESSION['sessionID'] = $session_index;

/*
session_start();*/