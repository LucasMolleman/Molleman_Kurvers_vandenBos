<?php

	if (file_exists('../../credentials.php')) include('../../credentials.php');
	elseif (file_exists('../../../credentials.php')) include('../../../credentials.php');
	else include('credentials.php');

	error_reporting(~E_NOTICE);
	require('sessionStart.php');

	define("PROJECTID",$_SESSION['projectID']);

	session_write_close();

	//define("PROJECTID",$_COOKIE['projectID']);

	function readParameter($name)
	{//example: $totalPlayers=readParameter("totalPlayers");

		$table_name=PROJECTID."globals";
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="SELECT * FROM $table_name WHERE (name='$name')";
		
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
		if ($row=mysqli_fetch_array($result)) {
			$value=$row['value'];
		}
		RETURN $value;
	}
	
	function readHandler($name)
	{
		$table_name=PROJECTID . "expSettings";
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="SELECT * FROM $table_name WHERE (name='$name')";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
		if ($row=mysqli_fetch_array($result)) {
			$value=$row['value'];
		}
		else $value="";
		RETURN $value;
	}
	
	//Retrieves a variable from a specific record
	function getValue($table_name,$condition,$name)
	{//example: $previousDecision=getValue("decisions","playerNr='$playerNr' and period='$period-1'","decision");
		$table_name_server = PROJECTID . $table_name;
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="SELECT $name FROM $table_name_server WHERE ($condition)";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
		if ($row=mysqli_fetch_array($result)) {
			$value=$row[$name];
		}
		else $value="";
		RETURN $value;
	}
function getColValues($table_name,$condition,$name)
{//example: $previousDecision=getValue("decisions","playerNr='$playerNr' and period='$period-1'","decision");
    $table_name_server = PROJECTID . $table_name;
    $conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
    $sql="SELECT $name FROM $table_name_server WHERE ($condition)";
    $result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
    $names = explode(",",$name);
    $values = [];
    if ($row=mysqli_fetch_array($result)) {
        foreach($names as $name)
        $values[]=$row[$name];
    }
    else $value="";
    RETURN $values;
}

	//Retrieves an array of variables from a specific record
	function getValues($table_name,$condition,$name, $sortBy)
	{//example: $previousDecision=getValues("decisions","groupNr='$groupNr' and period='$period-1'","decision");
		$table_name_server = PROJECTID . $table_name;
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="SELECT $name FROM $table_name_server WHERE ($condition) ORDER BY ($sortBy) ASC";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
		$values = [];
		while ($row = mysqli_fetch_assoc($result)) {
			$values[] =  $row[$name];
		}
		RETURN $values;
	}

	function getTable($table_name){
        $table_name_server = PROJECTID . $table_name;
        $conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
        $sql="SELECT * FROM $table_name_server";
        $result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
        $values = $result->fetch_all(MYSQLI_ASSOC);
        RETURN $values;
	}

	function getValuesNotEgo($table_name,$condition,$name, $sortBy)
	{
		$table_name_server = PROJECTID . $table_name;
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="SELECT $name FROM $table_name_server WHERE ($condition) ORDER BY ($sortBy) ASC";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
		$values = [];
		while ($row = mysqli_fetch_assoc($result)) {
			$values[] =  $row[$name];
		}
		RETURN $values;
	}

	//inserts new record in table
	//example: insertRecord("decisions","playerNr, period, decision","\"$playerNr\", \"$period\", \"$decision\" ");
	function insertRecord($table_name,$names,$values)
	{	
		$table_name_server = PROJECTID . $table_name;
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="INSERT INTO $table_name_server (".$names.") VALUES (".$values.")";
        if (preg_match('/"/', $names)>0) $mod_names=str_getcsv($names, ",", "\"");
        else $mod_names=str_getcsv($names, ",", "'");
        if (preg_match('/"/', $names)>0) $mod_values=str_getcsv($values, ",", "\"");
        else $mod_values=str_getcsv($values, ",", "'");
        $update_values = [];
		foreach ($mod_names as $key=>$val)
			array_push($update_values, $val."='".$mod_values[$key],"'");
        $sql.=" ON DUPLICATE KEY UPDATE ".implode(',',$update_values);

		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
	}

	//Updates a variable in a record
	function setValue($table_name,$condition,$name,$value)
	{
		$table_name_server = PROJECTID . $table_name;	
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="UPDATE $table_name_server SET $name=\"$value\" WHERE ($condition)";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
	}
	
	// the escape sequence \" needs to be added when you want to pass a string to this function
	function setValues($table_name,$condition,$updatestring)
	{
		$table_name_server = PROJECTID . $table_name;	
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="UPDATE $table_name_server SET ".$updatestring." WHERE ($condition)";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
	}

	function resetWaitingValues($playerNr)
	{
		$table_name_server = PROJECTID . "core";
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql = "SHOW COLUMNS FROM " . $table_name_server;
		$result = mysqli_query($conn,$sql);
		$allVars = [];

		while($row = mysqli_fetch_array($result)){
			$allVars [] = $row['Field'];
		}
		$clause = "playerNr=" . $playerNr;
		for ($i=0; $i<count($allVars); $i++) {
			if (substr($allVars[$i], 0, 5)=='wait_') {
				setValue("core", $clause, $allVars[$i], 0);
			}
		}
//		return $allVars[5];
	}

	function addColumn($table_name,$name,$dataType)
	{
		$table_name_server = PROJECTID . $table_name;
		$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
		$sql="ALTER TABLE $table_name_server ADD $name $dataType NOT NULL";
		$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
	}

	//returns an array of the variables saved in the cookie with the function 'writecookie'
	function readcookie($variable)
	{
		$cookie_val=$_COOKIE[$variable];
		return explode("-",$cookie_val);
	}

	//writes a cookie to the client's browser
	function writecookie() 
	{
		$numargs = func_num_args();
		$arg_list = func_get_args();
		
		$cookie_val =$arg_list[1];
		for ($i = 2; $i <= LENGTHCOOKIE; $i++) 
		{
			if ($i<$numargs) 
			{
				$cookie_val .="-".$arg_list[$i];
			}
			else 
			{
				$cookie_val .="- ";
			}
		}
		setcookie($arg_list[0], $cookie_val); 
	}



