<?php
	include('sql_library.php');
	$tableName=$_REQUEST['tableName'];
	$condition=$_REQUEST['condition'];
	$condition=str_replace("+", " ", $condition);
	$varName=$_REQUEST['varName'];
	$value=$_REQUEST['value'];
	setValue($tableName, $condition, $varName, $value);
