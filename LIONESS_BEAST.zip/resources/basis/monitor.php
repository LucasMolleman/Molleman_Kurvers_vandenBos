<?php
// load the library to regulate reading from and writing to the database

$result = mysqli_query($conn, "SHOW TABLES LIKE '" . PROJECTID . "%'");
$tableList = [];
while ($tables = mysqli_fetch_array($result)) $tableList[] = $tables[0];

$stageNamesArr = $_SESSION['stageNames'];
$stageNrs = array_keys($stageNamesArr);
$stageNames = [];
for ($i = 0; $i < count($stageNrs); $i++) $stageNames[] = $stageNamesArr[$stageNrs[$i]];

//	print_r($_SESSION['stageNum']);

?>
<script>
    // jQuery for browsing tables
    var tables = <?php echo json_encode($tableList); ?>;
    var stageNames = <?php echo json_encode($stageNames); ?>;
    var stageNrs = <?php echo json_encode($stageNrs); ?>;
    var projectID = <?php echo json_encode(PROJECTID); ?>;

    // upon new page entry, show first tables and its variables by default
    // also pre-select useful variables from other tables to guide new useres
    var activeTable = localStorage['activeTable'];
    if (!activeTable) {
        activeTable = 0; // start with core table if no localStorage is found
        localStorage['activeTable'] = 0;
        var preselectedVars = [0, 1, 2, 6];
        for (let i = 0; i < preselectedVars.length; i++) localStorage[projectID + 'core_tcol' + preselectedVars[i]] = 1;
        preselectedVars = [0, 1, 3];
        for (let i = 0; i < preselectedVars.length; i++) localStorage[projectID + 'decisions_tcol' + preselectedVars[i]] = 1;
        preselectedVars = [0, 1, 2, 3];
        for (let i = 0; i < preselectedVars.length; i++) localStorage[projectID + 'globals_tcol' + preselectedVars[i]] = 1;

    }
    // show the variable selection menu by default
    localStorage['varMenu'] = 1;

    // once the page is loaded, start the functions that refresh the data tables regularly so that monitoring progress is live
    $(document).ready(function () {
        $(".tabs-menu").click(function (event) {
            clearInterval(refreshTable);
            event.preventDefault();

            // if a new table is selected, update the localstorage
            localStorage['activeTable'] = ($(this).attr("href").substr(-1));

            // show that table
            $(this).parent().addClass("current");
            $(this).parent().siblings().removeClass("current");
            var tab = $(this).attr("href");
            //$(".tab-content").not(tab).css("display", "none");
            $(tab).fadeIn();

            // show the contents of that table
            var tableName = tables[localStorage['activeTable']];
            var tabNames = loadVariables(tableName);
            loadVariables2(tableName);
            loadTable();

            // start the refreshing procedure
            refreshTable = setInterval(function () {
                loadTable();
            }, 2000);
        });
        // make the selected variables blue in the menu (so that they look selected)
        loadVariables2(tableName);
        $('#li' + tableName).addClass('active');
    });

    // define function for viewing the variables
    function loadVariables(tableNameActive) {
        return JSON.parse($.ajax({
            type: 'GET',
            url: 'loadVariables.php',
            dataType: 'json',
            data: {tableName: tableNameActive},
            global: false,
            async: false,
            success: function (data) {
                return data;
            }
        }).responseText);
    }

    // menu for (de)selecting variables
    function loadVariables2(tableNameActive) {
        // asynchronously interacting with the database
        var xmlhttp;
        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            // when we are ready, show the variables
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                // which variables does the experimenter want to see?
                var variables = JSON.parse(xmlhttp.responseText);
                for (var i = 0; i < variables.length; i++) {
                    if (variables[i].substring(0, 5) === 'time_') {
                        var key1 = variables[i].substring(5);
                        var pos = stageNrs.indexOf(parseInt(key1));
                        var stageName = stageNames[pos];
                        variables[i] = 'time_' + stageName;
                    }
                }
                var txt = '';

                // define the show/hide variables menu. give ids according to the order in which they appear
                txt += '<form name="tcol" onsubmit="return false"><p>Click variables to show/hide</p>';
                for (var i = 0; i < variables.length; i++) {
                    txt += '<button id=' + tableNameActive + '_col' + i + ' name=' + tableNameActive + '_col' + i + ' onclick="toggleVis(this.name); loadTable()" class="btn';
                    // if the variable has been selected, make it blue
                    if (localStorage[tableNameActive + '_tcol' + i]) txt += ' btn-info';
                    else txt += '';
                    txt += '">' + variables[i] + '</button>';
                    if (i < (variables.length - 1)) txt += '&nbsp&nbsp';
                }
                txt += '</form>';

                // table sorting form
                txt += '<form onsubmit="sortTable(); loadTable(); return false">';
                txt += 'Sort table by ';
                txt += '<select id="sortBy">';
                for (var i = 0; i < variables.length; i++) {
                    txt += '<option value=' + i;
                    if (localStorage[tableNameActive + '_orderByVar'] == variables[i]) txt += ' selected';
                    txt += '>' + variables[i] + '</option>';
                }
                txt += '</select>';

                txt += '<select id="sortOrder">';
                txt += '<option value="0"';
                if (localStorage[tableNameActive + '_ascOrDesc'] == 0) txt += ' selected';
                txt += '> Ascending </option>';
                txt += '<option value="1"';
                if (localStorage[tableNameActive + '_ascOrDesc'] == 1) txt += ' selected';
                txt += '> Decending </option>';
                txt += '</select>';
                txt += '<input type="submit" value="Sort" class="btn">';
                txt += '</form>';

                //print the whole thing to the screen
                document.getElementById("varMenu").innerHTML = txt;
            }
        };
        // check which variables should be read from the database
        var reqVars = 'loadVariables.php?tableName=' + tableNameActive;
        xmlhttp.open("GET", reqVars, true);
        xmlhttp.send();
    }

    // the function loading the data from the database
    function loadTable() {
        // look in this table
        var tableNameActive = tables[localStorage['activeTable']];
        // these variables should be retrieved
        var tabNames = loadVariables(tableNameActive);
        var xmlhttp;
        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("showTableMonitor").innerHTML = xmlhttp.responseText;
            }
        };

        // check which variables should be read from the database
        // compose a search query called 'reqCols' (sent to server at the end)
        var reqCols = 'showTableMonitor.php?projectID=<?php echo PROJECTID?>&';
        var firstVar = 0;
        var cntVars = 0;
        for (var i = 0; i < tabNames.length; i++) {
            var varName = localStorage.getItem(tableNameActive + '_tcol' + i);
            if (varName) {
                if (firstVar == 1) reqCols += '&';
                reqCols += 'q' + cntVars + '=' + tabNames[i];
                firstVar = 1;
                cntVars++;
            }
        }
//	var sortTableBy = localStorage['orderByVar'];
        reqCols += '&orderBy=' + localStorage[tableNameActive + '_orderByVar'];
        reqCols += '&ascOrDesc=' + localStorage[tableNameActive + '_ascOrDesc'];

        reqCols += '&n=' + cntVars;
        // this should be changed!
        reqCols += '&tableName=' + tableNameActive;
//	alert(reqCols);
        xmlhttp.open("GET", reqCols, true);
        xmlhttp.send();
    }

    function sortTable() {
        var tableNameActive = tables[localStorage['activeTable']];
        var tabNames = loadVariables(tableNameActive);
        var varNameID = document.getElementById('sortBy').value;
        localStorage[tableNameActive + '_orderByVar'] = tabNames[varNameID];
        var ascDesc = document.getElementById('sortOrder').value;
        localStorage[tableNameActive + '_ascOrDesc'] = ascDesc;
    }
</script>

<div id="Monitor">
    <h3><?php echo $_SESSION['gameTitle']; ?> - Control panel</h3>
    <h6 style="color: grey;">address for
        participants: <?php echo $_SERVER['SERVER_NAME'] . str_replace('Control', 'Participant', $_SERVER['PHP_SELF']); ?> </h6>

    <script>
        // first display the tabs to browse through the tables
        var l = <?php echo strlen(PROJECTID); ?>;
        var tables = <?php echo json_encode($tableList); ?>;
        var txt = '';
        txt += ' <ul class="nav nav-tabs">';
        for (var i = 0; i < tables.length; i++) txt += '<li id="li' + tables[i] + '"><a class="tabs-menu" data-toggle="tab" href="#tab-' + i + '">' + tables[i].split("_").pop() + '</a></li>';
        txt += '</ul>';

        txt += '<button type="button" onclick="toggleVarMenu()"><div id="button_sign" style="padding:0"> > </div></button> Display options';
        txt += '<br clear=both>';

        document.write(txt);
    </script>
    <!-- the variable selection box -->
    <div id="varMenu" name="varMenu" class="alert alert-info"></div>
    <div>
        <table id="showTableMonitor" class="table table-striped"></table>
    </div>


    <script>
        // load the variable names from PHP
        var tableName = tables[activeTable];
        var tabNames = loadVariables(tableName);
        var tableNameActive = tables[localStorage['activeTable']];

        // function for table display
        var showMode = 'table-cell';
        if (document.all) showMode = 'block';

        // initialise visible columns from cache
        for (var i = 0; i < tabNames.length; i++) {
            cells = document.getElementsByName(tableNameActive + '_tcol' + i);
            var varName = localStorage.getItem(tableNameActive + '_tcol' + i);
        }

        // show and hide table elements
        function toggleVis(btn1) {
            var tableNameActive = tables[localStorage['activeTable']];
            var btn = btn1.substr(btn1.length - 1);
            if (btn1.substr(btn1.length - 2, btn1.length - 1) % 1 == 0) btn = btn1.substr(btn1.length - 2);
            if (btn1.substr(btn1.length - 3, btn1.length - 2) % 1 == 0) btn = btn1.substr(btn1.length - 3);

            if (localStorage[tableNameActive + '_tcol' + btn] != 1) {
                localStorage[tableNameActive + '_tcol' + btn] = 1;
                document.getElementById(btn1).className = 'btn btn-info';
            } else {
                localStorage.removeItem(tableNameActive + '_tcol' + btn);
                document.getElementById(btn1).className = 'btn';
            }
        }

        document.getElementById("button_sign").innerHTML = ">";
        document.getElementById("varMenu").style.display = "none";
        if (localStorage['varMenu']) {
            document.getElementById("varMenu").style.display = "block";
            document.getElementById("button_sign").innerHTML = "v";
        }

        function toggleVarMenu() {
            var e = document.getElementById('varMenu');
            if (e.style.display == 'block') {
                e.style.display = 'none';
                document.getElementById("button_sign").innerHTML = ">";
                localStorage.removeItem('varMenu');
            } else {
                e.style.display = 'block';
                document.getElementById("button_sign").innerHTML = "v";
                localStorage['varMenu'] = 1;
            }
        }

        var refreshTable = setInterval(function () {
            loadTable();
        }, 3000);
    </script>
</div>