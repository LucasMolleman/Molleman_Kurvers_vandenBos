<?php
//	include('credentials.php');

	include('sql_library.php');
	$table_name = PROJECTID.'core';


	$playerNr=$_GET['playerNr'];


	$groupNr=getValue("core","playerNr=$playerNr","groupNr");
	$thisPage = getValue("core","playerNr=$playerNr","onPage");
	$waitingPageNr = substr($thisPage, 4);
	$waitingPageNr = explode('.',$waitingPageNr);
	$controllerVarName = 'wait_' . $waitingPageNr[0] . 'ready';
	$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
	$sql="SELECT playerNr FROM $table_name WHERE groupNr=$groupNr and $controllerVarName=1";
	$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);
	echo json_encode(mysqli_num_rows($result), JSON_NUMERIC_CHECK);
