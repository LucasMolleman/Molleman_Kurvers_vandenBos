<?php
	define ("PROJECTID","game123");
