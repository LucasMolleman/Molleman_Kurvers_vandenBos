<?php
include('sql_library.php');
$playerNr = getValue("core", "ipaddress = '".$_GET['ipaddress']."'", "playerNr");
echo json_encode($playerNr, JSON_NUMERIC_CHECK);
