<?php
	echo json_encode(time());

