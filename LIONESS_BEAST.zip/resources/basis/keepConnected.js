/**
 * Created by molleman on 10/10/2017.
 */
var pNr;
self.addEventListener("message", function(e) {
    pNr = e.data;
    var xhttp = new XMLHttpRequest(); // web workers do not support AJAX

    var callClientConnected = function () {
        xhttp.open("GET", "clientConnected.php?cc=1&playerNr="+pNr, true);
        xhttp.send();
        setTimeout(callClientConnected, 3000);
    };
    callClientConnected();
    /* the passed-in data is available via e.data */
}, false);

